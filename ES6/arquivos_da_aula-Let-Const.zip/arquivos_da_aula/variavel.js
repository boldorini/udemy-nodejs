// var serie = 'Friends'

// if(true){
//     serie = 'Game Of Thrones'
// }

// console.log(serie)

// ----------------------------

// var serie = 'Friends'

// if(true){
//     var serie2 = 'Game Of Thrones'
// }

// console.log(serie2)

// ----------------------------

// var serie = 'Friends'

// if(true){
//     let serie = 'Game Of Thrones'
//     console.log(serie)
// }
// console.log(serie)

// ----------------------------
const serie = 'Friends'
serie = 'The Walking Dead'

if(true){
    let serie = 'Game Of Thrones'
    console.log(serie)
}
console.log(serie)