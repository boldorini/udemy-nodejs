// var dobreDoValor = function (numero) {
//     return numero * 2
// }

// console.log(dobreDoValor(7))
// -------------------------------------------
// var dobreDoValor = numero => numero * 2

// ----------------------------

var dobreDoValor = numero => {
    let resultado = numero * 2
    return resultado
}

console.log(dobreDoValor(7))